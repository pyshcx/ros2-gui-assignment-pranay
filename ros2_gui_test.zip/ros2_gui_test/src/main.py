#!/usr/bin/env python3
import sys
from PySide6.QtWidgets import QApplication
from gui import ControlPanelApp

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ControlPanelApp()
    win.show()
    sys.exit(app.exec())

